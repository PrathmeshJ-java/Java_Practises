package com.psj.BlogApplicationrestapis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BlogApplicationrestapisApplicationTests {

	@Test
	void contextLoads() {
	}

}
