package com.psj.BlogApplicationrestapis.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.psj.BlogApplicationrestapis.Entities.User;

public interface UserRepository extends JpaRepository<User, Integer>{
	

}
